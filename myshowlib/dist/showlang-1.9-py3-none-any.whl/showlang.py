import sys

# 辅助工具：尝试把字符串转换成数字，让运算和判断能跑通
def auto_convert(env):
    for k in list(env.keys()):
        v = env[k]
        if isinstance(v, str):
            try: env[k] = int(v)
            except ValueError:
                try: env[k] = float(v)
                except ValueError: pass

# 辅助工具：收集大括号 {} 里面的代码块
def collect_block(lines, start_idx):
    block_lines = []
    brace_count = 1
    i = start_idx
    while i < len(lines) and brace_count > 0:
        next_line = lines[i]
        if '{' in next_line: brace_count += 1
        if '}' in next_line: brace_count -= 1
        if brace_count > 0:
            block_lines.append(next_line)
        i += 1
    return '\n'.join(block_lines), i

# 核心解释器逻辑
def run_show_lang(code, env=None):
    if env is None: env = {}
    output = []
    lines = code.strip().split('\n')
    i = 0
    
    while i < len(lines):
        line = lines[i].strip()
        i += 1
        
        if not line or line.startswith('#'): 
            continue

        # 1. 定义函数 (def 函数名 { ... })
        if line.startswith('def '):
            if '{' not in line:
                output.append("语法错误: def 后面要加 {")
                continue
            func_name = line[4:].split('{')[0].strip()
            block, i = collect_block(lines, i)
            env[func_name] = block

        # 2. 运行函数 (run 函数名)
        elif line.startswith('run '):
            func_name = line[4:].strip()
            if func_name in env and isinstance(env[func_name], str):
                res = run_show_lang(env[func_name], env)
                if res: output.append(res)
            else:
                output.append(f"找不到函数: {func_name}")

        # 3. 接收输入 (ask 变量名)
        elif line.startswith('ask '):
            var_name = line[4:].strip()
            user_input = input(f"[终端等待输入 {var_name}]: ")
            env[var_name] = user_input

        # 4. 列表 (list 列表名 | 元素1 | 元素2)
        elif line.startswith('list '):
            parts = line[5:].split('|')
            if len(parts) >= 2:
                target = parts[0].strip()
                items = [item.strip().replace('$', ' ') for item in parts[1:]]
                env[target] = items
            else:
                output.append("语法错误: list 名字 | 元素1 | 元素2")

        # 5. 【你的新发明】运算 (calc_c_a+b*2)
        elif line.startswith('calc_'):
            rest = line[5:]
            parts = rest.split('_', 1)
            if len(parts) == 2:
                target = parts[0].strip()  # 结果是 c
                expr = parts[1].strip()    # 表达式是 a+b*2
                auto_convert(env)
                try:
                    # 借用 Python 的 eval 算一下
                    env[target] = eval(expr, {}, env)
                except Exception as e:
                    output.append(f"计算错误: {e}")
            else:
                output.append("语法错误: 请用 calc_结果_表达式 的格式")

        # 6. 条件判断 (if 条件 { ... })
        elif line.startswith('if '):
            cond = line[3:].split('{')[0].strip()
            block, i = collect_block(lines, i)
            auto_convert(env)
            try:
                if eval(cond, {}, env):
                    res = run_show_lang(block, env)
                    if res: output.append(res)
            except Exception as e:
                output.append(f"判断错误: {e}")

        # 7. 循环 (loop 次数 { ... })
        elif line.startswith('loop '):
            times_str = line[5:].split('{')[0].strip()
            block, i = collect_block(lines, i)
            auto_convert(env)
            try:
                times = int(eval(times_str, {}, env))
                for _ in range(times):
                    res = run_show_lang(block, env)
                    if res: output.append(res)
            except Exception as e:
                output.append(f"循环错误: {e}")

        # 8. 你的老本行：变量赋值 (a_hello$world)
        # 注意：这个必须放在 calc_ 后面，因为 calc_ 也带下划线
        elif '_' in line and not line.startswith('show'):
            k, v = line.split('_', 1)
            env[k.strip()] = v.strip().replace('$', ' ')

        # 9. 打印输出 (show"a")
        elif line.startswith('show'):
            target = line[4:].strip().strip('"')
            if target in env:
                if isinstance(env[target], list):
                    output.append(" ".join(str(x) for x in env[target]))
                else:
                    output.append(str(env[target]))
            else:
                output.append(target)

        else:
            output.append(f"未知指令: {line}")

    return '\n'.join([o for o in output if o != ''])

# 命令行入口
def main():
    if len(sys.argv) < 2:
        print("ShowLang 交互式终端 (输入 exit 退出)")
        env = {}
        while True:
            try:
                line = input("show> ")
                if line.strip() == 'exit': break
                if not line.strip(): continue
                if '{' in line or '}' in line:
                    print("终端暂不支持多行块，请写入 .sw 文件运行")
                    continue
                result = run_show_lang(line, env)
                if result: print(result)
            except KeyboardInterrupt:
                print("\n退出终端..."); break
            except Exception as e:
                print(f"错误: {e}")
        return

    file_name = sys.argv[1]
    if not file_name.endswith('.sw'):
        print("错误: ShowLang 只能运行 .sw 结尾的文件")
        sys.exit(1)
    try:
        with open(file_name, 'r', encoding='utf-8') as f:
            code = f.read()
        result = run_show_lang(code)
        print(result)
    except FileNotFoundError:
        print(f"找不到文件: {file_name}")
    except Exception as e:
        print(f"运行出错: {e}")

if __name__ == '__main__':
    main()
