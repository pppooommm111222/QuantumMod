import sys

# 核心解释器逻辑
def run_show_lang(code, env=None):
    if env is None:
        env = {}
    output = []
    for line in code.strip().split('\n'):
        line = line.strip()
        if not line or line.startswith('#'): 
            continue
        
        if line.startswith('show'):
            target = line[4:].strip().strip('"')
            output.append(str(env.get(target, target)))
        elif '_' in line:
            k, v = line.split('_', 1)
            env[k.strip()] = v.strip().replace('$', ' ')
    return "\n".join(output)

def main():
    # ==========================================
    # 十字路口：检查用户输入时有没有带文件参数
    # ==========================================
    if len(sys.argv) < 2:
        # 【模式 1：专属终端模式】
        print("ShowLang 交互式终端 (输入 exit 退出)")
        env = {}
        while True:
            try:
                line = input("show> ")
                if line.strip() == 'exit':
                    break
                if not line.strip():
                    continue
                result = run_show_lang(line, env)
                if result:
                    print(result)
            except KeyboardInterrupt:
                print("\n退出终端...")
                break
        return  # 终端模式结束后，直接结束程序

    # ==========================================
    # 【模式 2：文件运行模式】
    # 如果你没在上面 return，说明你带了文件参数，比如 test.sw
    # ==========================================
    file_name = sys.argv[1]
    
    if not file_name.endswith('.sw'):
        print("错误: ShowLang 只能运行 .sw 结尾的文件")
        sys.exit(1)
        
    try:
        with open(file_name, 'r', encoding='utf-8') as f:
            code = f.read()
        result = run_show_lang(code)
        print(result)
    except FileNotFoundError:
        print(f"找不到文件: {file_name}")
    except Exception as e:
        print(f"运行出错: {e}")

if __name__ == '__main__':
    main()
